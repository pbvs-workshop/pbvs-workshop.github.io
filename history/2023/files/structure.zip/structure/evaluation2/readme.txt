SR files should be upload in x2 scale folder, with camera axis prefix and 2 digits sequential. e.g.
axis01.jpg
axis02.jpg
...
axis10.jpg