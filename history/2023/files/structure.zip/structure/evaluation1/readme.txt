SR files should be upload in it respective scale folder, with camera prefix (domo,axis,flir) and 2 digits sequential. e.g.
domo01.jpg
domo02.jpg
...
domo10.jpg
axis01.jpg
axis02.jpg
...
axis10.jpg
flir01.jpg
flir02.jpg
...
flir10.jpg