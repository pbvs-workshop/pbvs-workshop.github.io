SR files should be upload in it respective folder, with camera prefix (flir) and 2 digits sequential. e.g.
flir01.jpg
flir02.jpg
...
flir10.jpg