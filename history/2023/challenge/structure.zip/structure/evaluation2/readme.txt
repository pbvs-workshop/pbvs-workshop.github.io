SR files should be upload in x2 scale folder, with camera axis prefix and 2 digits sequential. e.g.
axis01.jpg
axis02.jpg
...
axis10.jpg
Please remember, the x2 scale proposed solution should be able to tackle both problems, i.e., generating the super-resolution of the images acquired with the camera Axis Q2901-E camera; as well as mapping images from one domain (Axis Q2901-E camera) to another domain (FLIR FC-632O camera).